
------------------------
HOW TO COMPILE AND RUN
------------------------
Compile: g++ -std=c++17 candystore.cpp board.cpp player.cpp  gamedriver.cpp
------------------------
DEPENDENCIES
------------------------
candystore.cpp board.cpp player.cpp  gamedriver.cpp must be in the same directory as the cpp files in order to compile. 
Must have candy.txt, players.txt, results.txt, riddles.txt, and specialitems.txt 
named as such for read functions to compile and in the same directory.
------------------------
SUBMISSION INFORMATION
------------------------
CSCI1300 Fall 2023 Project 2
Author: Jake Lewis
Recitation: 606- Juan Vasquez
Date: Dec 6, 2023
------------------------
ABOUT THIS PROJECT
------------------------
This project is modedled after the game candyland, with added calamites and special items for the player to discover.
The goal is to get to the castle tile as quick as possible, while navigating the treachourous
candyland map. Have fun!
