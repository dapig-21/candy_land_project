#include "Board.h"
#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;
vector <Candy>readCandy(string file_name, vector <Candy> candies){
    Candy candyobj;
    string price;
    ifstream candys;
    string line="";
    candys.open(file_name);
   
    if(candys.fail()){
        cout<<"Failed to open file"<<endl;
        return candies;
    }
    else{
        while(getline(candys,line)){
            stringstream ss(line);
            getline(ss, candyobj.name, '|' );
            if(candyobj.name==""){
                continue;
            }
            getline(ss, candyobj.description, '|');

            getline(ss, price, '|');
            candyobj.price=stod(price);
            
            getline(ss, candyobj.candy_type, '|');

            candies.push_back(candyobj);

        }
        candys.close();

    }
    return candies;
}   
int main()
{
    string filename;
    vector <Candy> candies;
    cout<<"What File"<<endl;
    cin>>filename;
    candies = readCandy(filename, candies);
    Board board;
    board.addCandyStore(30);
      board.displayBoard();
    board.movePlayer1(30);
    int player_1_position=board.getPlayer1Position();
    
    board.movePlayer2(24);
    board.displayBoard();
    if(board.isPosition1CandyStore(player_1_position)){
        cout<<"Welcome to the candy store!"<<endl;
        cout<<"Here's the selection: "<<endl;
        for(int i=0; i<candies.size(); i++){
            cout<<candies.at(i).name<<endl;
        }
    }
    return 0;
}