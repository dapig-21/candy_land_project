#include "Player.h"




vector <Player>  Player :: readPlayers(){
    vector <Candy> player_inventory;
    vector <Player> playable_characters;
    string name;
    string stamina;

    string gold;
    string inventory;
    string candy;
    ifstream playersstream;
    string line="";
    playersstream.open("players.txt");
   
    if(playersstream.fail()){
        cout<<"Failed to open file"<<endl;
        return playable_characters;
    }
    else{
        while(getline(playersstream,line)){
            Player player1;
            stringstream ss(line);
            
            getline(ss, name, '|' );
            player1.setName(name);
            if(player1.getName()==""){
                continue;
            }
            getline(ss, stamina, '|');
            player1.setStamina(stoi(stamina));
            

            getline(ss, gold, '|');
            player1.setGold(stoi(gold));

            getline(ss, inventory, '|');
            stringstream ss2(inventory);
            //cout<<inventory<<endl;
            while(getline(ss2, candy, ',')){
                //cout<<candy<<endl;
                player1.addCandy(stringToCandy(candy));
                
            }
            playable_characters.push_back(player1);
            

            

        }
        playersstream.close();

    }
    return playable_characters;
}  



bool compareString1(string str1, string str2){
    if(str1.length()!= str2.length()){
        return false;
    }
    int len = str1.length();
    for(int i=0; i<len; i++){
        if(tolower(str1[i])!=tolower(str2[i])){
            return 0;
        }
    }
    return true;
}

/*FOR CHECK ROBBERS REPEL


bool type

for(int i =0; i<8; i++){
    if _inventory[i].name=="Robbers Repel";
    return true
    else{
        return false
    }
}



*/

/* FOR CHECK IMMUNITY CANDY
for(int i =0; i<8; i++){
    if _inventory[i].type=="Immunity"
    return true

    else{
        return false;
    }
}

*/
/*FOR PLAY ROCK PAPER SCISSORS
take previous rock paper scissors game
only accept one player input, generate a random of 1-3 
to decide computer output
augment player inventory based on winning or losing 
return true for a win, and false for a loss
*/
Player::Player(){
    Candy Empty{"Empty","","",0,0.0,""};
    _stamina=0;
    _candy_amount=0;
    _gold=0;
    _effect="";
    for(int i=0;i<_MAX_CANDY_AMOUNT;i++){
    _inventory[i]= Empty;
    }
    Candy candy;
    //={Candy Empty, Empty, Empty, Empty};

}

Player::Player(int stamina, double gold, string effect, Candy candy_array[], const int CANDY_ARR_SIZE ){
    Candy Empty{"Empty","","",0,0.0,""};
    _stamina=stamina;
    _gold=gold;
    _effect=effect;
    _candy_amount=0;
    if(CANDY_ARR_SIZE!=_MAX_CANDY_AMOUNT){
        for(int i=0;i<CANDY_ARR_SIZE;i++){
            if(candy_array[i].name.length()==0){
                    _inventory[i]=Empty;
                }
            else{
            _inventory[i]=candy_array[i];
            }
            }
    
    for(int i=1; i<=_MAX_CANDY_AMOUNT-CANDY_ARR_SIZE; i++){
        _inventory[_MAX_CANDY_AMOUNT-i]=Empty;
        }
    }
    else{
        for(int i=0;i<_MAX_CANDY_AMOUNT;i++){
            if(candy_array[i].name==""){
                _inventory[i]=Empty;
            }
        else{
            _inventory[i]=candy_array[i];}
        }
}
    for(int i=0; i<_MAX_CANDY_AMOUNT; i++){
        if (_inventory[i].name!="Empty"){
            _candy_amount++;
        }
    }
}
Candy Player:: stringToCandy(string candy){
    Candy candyobj;
    bool flag=false;
    vector <Candy> all_candies=CandyStore :: readCandy();
    
    for(int i=0; i<int(all_candies.size()); i++){
        if(compareString1(candy, all_candies.at(i).name)){
            candyobj=all_candies.at(i);
            flag=true;
        }

    }
    if(!flag){
        cout<<"bad!"<<endl;
    }
    //cout<< "stoc "<< candyobj.name<<endl;
    return candyobj;
}

int Player::getCandyAmount(){
    return _candy_amount;
}

void Player:: setName(string name){
    _name=name;
}

string Player:: getName(){
    return _name;
}

void Player::setStamina(int stamina){
     _stamina=stamina;

}
int Player:: getStamina(){
    return _stamina;
}

void Player::setGold(double gold){
    _gold=gold;
}
double Player:: getGold(){
    return _gold;
}

void Player::setEffect(string effect){
    _effect=effect;
}

string Player:: getEffect(){
    return _effect;
}

void Player:: printInventory(){
for (int i=0; i<_MAX_CANDY_AMOUNT;i++){
    if(i==3||i==6||i==9){
        cout<<"|"<<endl;
    }
    string whattoprint="";
    if(_inventory[i].name=="Empty"){
        whattoprint="Empty";
    }
    else{
        whattoprint=_inventory[i].name;
    }
    cout<<"|["<<whattoprint<<"]";
    }
    cout<<"|"<<endl;
}
Candy Player:: findCandy(string candy_name){
    Candy Empty{"Empty","","",0,0.0,""};
    Candy ReallyEmpty{"","","",0,0.0,""};
    //  bool found=false;
    for(int i=0; i<_MAX_CANDY_AMOUNT; i++){
        if(_inventory[i].name=="Empty"){
            // found=true;
            return ReallyEmpty;
            break;
        }
        /*
        compareString(_inventory[i].name, candy_name)
        */
        else if (compareString1(_inventory[i].name, candy_name)){
            return _inventory[i];
        }
       
    }
    return Empty;
}


 bool Player:: addCandy(Candy candy){
    string lowercandy;
    
    for(int i=0; i<_MAX_CANDY_AMOUNT; i++){
        if(_inventory[i].name=="Empty"){ // maybe change to candy object if empty is a test case
            _inventory[i]=candy;
            _candy_amount++;
            return true;
        }
        
    }
    return false;
}
bool Player :: removeCandy(string candy_name){
    bool erased=false;
    Candy Empty{"Empty","","",0,0.0,""};
    


    for(int i=0; i<_MAX_CANDY_AMOUNT; i++){
        if(compareString1(_inventory[i].name, candy_name)&&!(_inventory[i].name=="Empty")){ //new
            _inventory[i]=Empty;
            _candy_amount=_candy_amount-1;
            erased=true;
            break;
            }
        }
     if(erased==true){
        for(int i=0; i<_MAX_CANDY_AMOUNT-1; i++){
            if (_inventory[i].name=="Empty"){
                _inventory[i]=_inventory[i+1];
                _inventory[i+1] = Empty;
            }
        }
        return true;
     }
    else{
        return false;
    }
}

void Player :: printStats(Player player){
    cout<< "Name: "<<player.getName()<<endl;
    cout<< "Stamina: "<<player.getStamina()<<endl;
    cout<< "Gold: "<< player.getGold()<<endl;
    cout<< "Candy Inventory: "<<endl;
    player.printInventory();
}



