#include "Board.h"
#include "candystore.h"
#include "Player.h"
#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;



int main()
{
    bool running=true;
    Board board;
    int player_desicion;
   
    CandyStore candystore1("store1");
    CandyStore candystore2("store2");
    CandyStore candystore3("store3");
    vector <Player> playable_characters;
    Player testplayer;
    playable_characters = testplayer.readPlayers();
    Player player1=playable_characters.at(1);
    
    player1.printStats(player1);
    
   

    cout<<candystore1.getLocation()<<endl;
    cout<<candystore2.getLocation()<<endl;
    cout<<candystore3.getLocation()<<endl;
    candystore1.printInventory();
    candystore2.printInventory();
    candystore3.printInventory();
     board.addCandyStore(candystore1.getLocation());
     board.addCandyStore(candystore2.getLocation());
     board.addCandyStore(candystore3.getLocation());
     board.displayBoard();
     //player1.printInventory();

       while(running){
        cout<<"enter 1 to draw a card"<<endl;
        cin>>player_desicion;
        if(player_desicion==1){
            board.movePlayer1(board.moveFromCard(board.drawCard()));
            board.displayBoard();
            if(board.isPosition1CandyStore(board.getPlayer1Position())){
            candystore1.printInventory();
        }
        else if(board.isSpecialTile1(board.getPlayer1Position())){
            cout<<board.decideSpecialTile()<<endl;
        }
        else if(!board.isSpecialTile1(board.getPlayer1Position())){
            board.checkCalamity();
        }
        }
        
        

        // if(board.isPosition1CandyStore(board.getPlayer1Position())){
        //     candystore1.printInventory();
            
        // }
        // else if(board.isSpecialTile1(board.getPlayer1Position())){
        //     cout<<board.decideSpecialTile()<<endl;
            
        // }
        
}
    
     



    //candystore1.printInventory();


    // string card = "";
    // card = board.drawCard();
    // cout <<card<<endl;

    
    

}