#ifndef CANDY_H
#define CANDY_H
#include <fstream>
#include <sstream>
#include <iostream>
#include <vector>
#include <iomanip>
#include <string>
#include "candystore.h"
using namespace std;





class Player{
    private:
        string _name;
        const static int _MAX_CANDY_AMOUNT=9;
        int	_stamina;
        double	_gold;
        string	_effect;
        int	_candy_amount;
        Candy _inventory [_MAX_CANDY_AMOUNT];
        const int _PLAYER_AMOUNT = 2;
        
        
    public:
        Player();
        Player(int stamina, double gold, string effect, Candy candy_array[], const int CANDY_ARR_SIZE);
        
        int getCandyAmount();
        
        void setStamina(int stamina);
        int getStamina();
        
        void setGold(double gold);
        
        double getGold();

        string getName();

        void setName(string name);

        void setEffect(string effect);

        void printStats(Player player);

        bool checkImmunityCandy();

        bool checkRobbersRepel();

        bool playRockPaperScissors(Player player1);

        string getEffect();

        void printInventory();
        Candy findCandy(string candy_name);

        bool addCandy(Candy candy);

        bool removeCandy(string candy_name);
        
        vector <Player> readPlayers();

         Candy stringToCandy(string candy);


};
#endif

