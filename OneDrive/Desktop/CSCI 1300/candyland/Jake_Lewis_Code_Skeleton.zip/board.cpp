#include "Board.h"




Board::Board()
{
    resetBoard();
}

/*
    FOR CALAMITIES
    take input of checkCalamity
    if(avalanche){
        setStamina(-5)
        playRockPaperScissors
        skip players turn

        }
    else if(candy bandits){
        if(!hasRepel){
            player.setGold(-10);
        }
    else if(Labrinyth){
        if(player_Doesn't_win){
            skip turn;
        }
    
    }
    else{
        if(!Magical Candy){
            skip turn;
        }
    }
    


*/

/*
FOR SPECIAL TILES
take the output of decideSpecialTile
if(shortcut tile){
    setPlayerPosition(+4);
}
else if (Ice Cream Shop){
    drawCard();
}

else if(Gumdrop forest){
    setGold(-5);
    setPlayerPosition(-4);
}
else{
    setPlayerPostion(previousPosition);
    if(hasimmunitycandy){
        remove immunity candy;
    }
}


*/


/*FOR READ RIDDLES
take the read candies function, augment it to needed specifications
store in the riddles array



*/

/* FOR EXECUTE RIDDLE
int i =0;
if playerposition==specialtileposition
    cout<<riddle[i].question<<endl;
    cin>>answer;
    if(answer=riddle[i].answer){
        do the thing based on the treasure
    }
    else{
        cout<<"Too bad"<<endl;
    }


*/

/*FOR sametileconstraint
I'm not sure how to show who was there first, i will figure it out.

    if player1postion==player2postion{
        if(!checkRobbersRepel)
        either player 1 or 2 gets candy stolen
        move either player 1 or 2 back 1
    }
*/





void Board::resetBoard()
{
    const int COLOR_COUNT = 3;
    const string COLORS[COLOR_COUNT] = {MAGENTA, GREEN, BLUE};
    Tile new_tile;
    string current_color;
    for (int i = 0; i < _BOARD_SIZE - 1; i++)
    {
        current_color = COLORS[i % COLOR_COUNT];
        new_tile = {current_color, "regular tile"};
        makeSpecialTiles();
        _tiles[i] = new_tile;
    }
    new_tile = {ORANGE, "regular tile"};
    _tiles[_BOARD_SIZE - 1] = new_tile;

    _candy_store_count = 0;
    for (int i = 0; i < _MAX_CANDY_STORE; i++)
    {
        _candy_store_position[i] = -1;
    }

    _player_1_position = 0;
    _player_2_position = 0;
}

int Board :: randomNumGen2(int min, int max) {
    random_device rd;   // Obtain a random number from a hardware device
    mt19937 gen(rd());  // Seed the random number generator
    uniform_int_distribution<> distribution(min, max);  // Define the distribution

    return distribution(gen);  // Generate and return a random number
}


Card Board::drawCard()
{
    Card cardobj;
    cardobj.color="";
    cardobj.double_move=false;
    //make a rando between 1-36
    // 1/4 red, 1/4 green, 1/4 blue, 1/8 any doubles
    
    srand(time(0));
    
    string card_color ="";

    int card_type= 1 + rand()%35;

    cout<<"Drawing card"<<endl;
    if(card_type>=1 && card_type<8){
        cardobj.color= MAGENTA;
        card_color="Magenta";
        cardobj.double_move=false;
    }
    else if(card_type>=8&& card_type<16){
        cardobj.color= GREEN;
        card_color="Green";
        cardobj.double_move=false;
    }
    else if(card_type>=16 && card_type<24){
        cardobj.color= BLUE;
        card_color="Blue";
        cardobj.double_move=false;;
    }
    else if(card_type>=24 && card_type<28){
        cardobj.color= MAGENTA;
        card_color="Magenta";
        cardobj.double_move=true;
    }
    else if(card_type>=28 && card_type<32){
        cardobj.color= GREEN;
        card_color="Green";
        cardobj.double_move=true;
    }
    else if(card_type>=32 && card_type<=35){
        cardobj.color= BLUE;
        card_color="Blue";
        cardobj.double_move=true;
    }
    if(cardobj.double_move==true){
        cout<<"You drew a "<<card_color<<" double"<<endl;
    }
    else{
        cout<<"You drew a regular "<<card_color<<endl;
    }
    return cardobj;
    
}
    
 void Board::checkCalamity(){
    /*
    Once functions for calamities are made, this will be a void and it will just run the function for each calamity
    */

     srand(time(0));
     int random = randomNumGen2(1,10);
     int calamity_random= randomNumGen2(1,100);
     bool calamity;
    //  cout<<"Num1 "<<random<<endl;
    //  cout<<calamity_random<<endl;
     if(random>=1 && random<=4){
        calamity=true;
       
     }
     else{
        calamity = false;
        //cout<<"No Calamity"<<endl;
        return;
     
     }
     if (calamity==true){
        if(calamity_random>=1 && calamity_random<=30){
            cout<<"Candy Bandits!"<<endl;

        }
        else if(calamity_random>=31 && calamity_random<=66){
            cout<<"Labrynth!"<<endl;
            
        }
        else if(calamity_random>=67 && calamity_random<=82){
            cout<<"AVALANCHE!!"<<endl;
            
        }
        else if(calamity_random>=83 && calamity_random<=100){
            cout<<"Sticky Taffy!"<<endl;
            
        }
     }
}







int Board:: moveFromCard(Card card_drawn){
    bool double_move=false;
    int amount_to_move;
    string current_tile_color=_tiles[getPlayer1Position()].color;
    if (card_drawn.double_move==true){
        double_move=true;
    }
    for (int i=1; i<4; i++){
        if(card_drawn.color==_tiles[getPlayer1Position()+i].color){
            amount_to_move=i;
            break;
        }

    }
    if(double_move){
        cout<<"Moving "<<amount_to_move+3<<endl;
        return amount_to_move+3;
    }
    else{
        cout<<"Moving "<<amount_to_move<<endl;
        return amount_to_move;
    }
    

}
    
string Board :: decideSpecialTile(){
    int ran= randomNumGen2(1,4);
    if(ran==1){
        return "Shortcut Tile";
    }
    else if (ran==2){
        return " Ice Cream Stop Tile";
    }
    else if(ran==3){
        return "Gumdrop Forest Tile";
    }
    else{
        return "Gingerbread House Tile";
    }
}

bool Board:: isTileCandyStore(int position){
    for(int i=0; i<_MAX_CANDY_STORE;i++){
        if (position==_candy_store_position[i]){
            return true;
        }

    }
    return false;
}

bool Board::isSpecialTile1(int position){
    if(_tiles[_player_1_position].tile_type=="Special"){
        return true;
    }
    return false;
}

bool Board::isSpecialTile2(int position){
    if(_tiles[_player_2_position].tile_type=="Special"){
        return true;
    }
    return false;
}

 void Board :: makeSpecialTiles(){
    
    for(int i=0; i<_BOARD_SIZE; i++){
       int ran = randomNumGen2(0, _BOARD_SIZE);
       if(i==ran){
        _tiles[i].tile_type="Special";
       }
    }
 }





void Board::displayTile(int position)
{
    if (position < 0 || position >= _BOARD_SIZE)
    {
        return;
    }
    Tile target = _tiles[position];
    cout << target.color << " ";
    if (position == _player_1_position)
    {
        cout << "1";
    }
    else if(position == _player_2_position)
    {
        cout<<"2";
    }
    else if(isTileCandyStore(position))
    {
        cout<<"C";
    }
    else if (_tiles[position].tile_type=="Special"){
        cout<<"S";
    }
    
    else
    {
        cout << " ";
    }
    cout << " " << RESET;
}

void Board::displayBoard()
{
    // First horizontal segment
    for (int i = 0; i <= 23; i++)
    {
        displayTile(i);
    }
    cout << endl;
    // First vertical segment
    for (int i = 24; i <= 28; i++)
    {
        for (int j = 0; j < 23; j++)
        {
            cout << "   ";
        }
        displayTile(i);
        cout << endl;
    }
    // Second horizontal segment
    for (int i = 52; i > 28; i--)
    {
        displayTile(i);
    }
    cout << endl;
    // Second vertical segment
    for (int i = 53; i <= 57; i++)
    {
        displayTile(i);
        for (int j = 0; j < 23; j++)
        {
            cout << "   ";
        }
        cout << endl;
    }
    // Third horizontal segment
    for (int i = 58; i < _BOARD_SIZE; i++)
    {
        displayTile(i);
    }
    cout << ORANGE << "Castle" << RESET << endl;
}

bool Board::setPlayer1Position(int new_position)
{
    if (new_position >= 0 && new_position < _BOARD_SIZE)
    {
        _player_1_position = new_position;
        return true;
    }
    return false;
}

bool Board::setPlayer2Position(int new_position)
{
    if (new_position >= 0 && new_position < _BOARD_SIZE)
    {
        _player_2_position = new_position;
        return true;
    }
    return false;
}

int Board::getBoardSize() const
{
    return _BOARD_SIZE;
}

int Board::getCandyStoreCount() const
{
    return _candy_store_count;
}

int Board::getPlayer1Position() const
{
    return _player_1_position;
}
int Board::getPlayer2Position() const
{
    return _player_2_position;
}

bool Board::addCandyStore(int position)
{
    if (_candy_store_count >= _MAX_CANDY_STORE)
    {
        return false;
    }
    _candy_store_position[_candy_store_count] = position;
    _candy_store_count++;
    return true;
}

bool Board::isPosition1CandyStore(int player_1_board_position)
{
    for (int i = 0; i < _candy_store_count; i++)
    {
        if(_candy_store_position[i] == player_1_board_position)
        {
            return true;
        }
    }
    return false;
}

bool Board::isPosition2CandyStore(int player_2_board_position)
{
    for (int i = 0; i < _candy_store_count; i++)
    {
        if(_candy_store_position[i] == player_2_board_position)
        {
            return true;
        }
    }
    return false;
}

bool Board::movePlayer1(int tile_to_move_forward)
{
    int new_player_position = tile_to_move_forward + _player_1_position;
    if(new_player_position < 0 || new_player_position >= _BOARD_SIZE)
    {
        return false;
    }
    _player_1_position = new_player_position;
    return true;
}

bool Board::movePlayer2(int tile_to_move_forward)
{
    int new_player_position = tile_to_move_forward + _player_2_position;
    if(new_player_position < 0 || new_player_position >= _BOARD_SIZE)
    {
        return false;
    }
    _player_2_position = new_player_position;
    return true;
}