#include "candystore.h"


int CandyStore :: randomNumGen(int min, int max) {
    random_device rd;   
    mt19937 gen(rd());  
    uniform_int_distribution<> distribution(min, max);  

    return distribution(gen);  
}




vector <Candy> CandyStore :: readCandy(){
    vector <Candy> all_candies;
    Candy candyobj;
    string price;
    string effect_value = "";
    ifstream candys;
    string line="";
    candys.open("candy.txt");
   
    if(candys.fail()){
        cout<<"Failed to open file"<<endl;
        return all_candies;
    }
    else{
        while(getline(candys,line)){
            stringstream ss(line);
            getline(ss, candyobj.name, '|' );
            if(candyobj.name==""){
                continue;
            }
            getline(ss, candyobj.description, '|');
            

            getline(ss, candyobj.effect_type, '|');

            getline(ss, effect_value, '|');
            candyobj.effect_value=stoi(effect_value);

            getline(ss, candyobj.candy_type, '|');

            getline(ss, price, '|');
            candyobj.price=stod(price);
            
            

            all_candies.push_back(candyobj);

        }
        candys.close();

    }
    return all_candies;
}  


CandyStore :: CandyStore(string name){
    vector <Candy> all_candies=readCandy();
    _name=name;
    setInventory(all_candies);
    _location = randomNumGen(1,83);

}

string CandyStore :: getName(){
    return _name;
}


int CandyStore :: getLocation(){
    return _location;
}

void CandyStore :: setLocation(int location){
    _location=location;
}
void CandyStore :: setName(string name){
    _name=name;
}

/*FOR BUY CANDY
candy empty;
for(int i=0 i<max_candy_amount; i++){
    if candy_to_buy==_store_selection[i].name
    setPlayerGold-store_selection[i].price;
    _store_selection[i]=empty
    
}



*/




void CandyStore:: setInventory(vector <Candy> all_candies){
    for (int j=0; j<3; j++){
    _store_selection[j]=all_candies.at(randomNumGen(0, all_candies.size()-1));
}
    
    
}



void CandyStore :: printInventory(){
    cout<<"Avalible Candies"<<endl;
    for(int i=0; i<3; i++){
        cout<<"Name: "<<_store_selection[i].name<<endl;
        cout<<"Description: "<<_store_selection[i].description<<endl;
        cout<<"Effect: "<<_store_selection[i].effect_type<<endl;
        cout<<"Effect Value: "<<_store_selection[i].effect_value<<endl;
        cout<<"Candy Type: "<<_store_selection[i].candy_type<<endl;
        cout<<"Price: "<<_store_selection[i].price<<endl;
        cout<<"------------------------"<<endl;
    }
}