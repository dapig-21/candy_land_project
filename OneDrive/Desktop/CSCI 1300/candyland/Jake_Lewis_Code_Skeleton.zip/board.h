#ifndef BOARD_H
#define BOARD_H

#include <iostream>
#include <vector>
#include <random>

// #include "Player.h"
#define RED "\033[;41m"     /* Red */
#define GREEN "\033[;42m"   /* Green */
#define BLUE "\033[;44m"    /* Blue */
#define MAGENTA "\033[;45m" /* Magenta */
#define CYAN "\033[;46m"    /* Cyan */
#define ORANGE "\033[48;2;230;115;0m"  /* Orange (230,115,0)*/
#define RESET "\033[0m"

using namespace std;

// struct Candy
// {
//     string name;
//     string description;
//     double price;
//     string candy_type;
// };


struct Riddle{
    string question;
    string answer;
};
struct Tile
{
    string color;
    string tile_type;
};

struct Card
{
    string color;
    bool double_move;
};


class Board
{
private:
    const static int _BOARD_SIZE = 83;
    Tile _tiles[_BOARD_SIZE];
    const static int _MAX_CANDY_STORE = 3;
    int _candy_store_position[_MAX_CANDY_STORE];
    int _candy_store_count;
    int _player_1_position;
    int _player_2_position;
    static const int riddle_amount=2;
    Riddle riddles[riddle_amount];
    // int _card_draw_probs [10] = {1,1,1,2,2,3,3,4,5,6};


public:
    Board();
    void resetBoard();
    void displayTile(int);
    void displayBoard();
    int randomNumGen2(int min, int max);
    bool setPlayer1Position(int);
    bool setPlayer2Position(int);
    
    
    //functions I am making
    Card drawCard();
    void checkCalamity();
    void makeSpecialTiles();
    void allChecks();
    void executeCalamity(string calamity);
    void executeSpecialTile(string speical_tile);
    void readRiddles();
    void executeRiddles();
    void sameTileConstraint();


    
    int getBoardSize() const;
    int getCandyStoreCount() const;
    int getPlayer1Position() const;
    int getPlayer2Position() const;
    int moveFromCard(Card card_drawn);
    
    
    bool addCandyStore(int);
    bool isTileCandyStore(int);
    bool isPosition1CandyStore(int); 
    bool isPosition2CandyStore(int);
    bool isSpecialTile1(int);
    bool isSpecialTile2(int);
    string decideSpecialTile();


    bool movePlayer1(int tile_to_move_forward);
    bool movePlayer2(int tile_to_move_forward);
};

#endif